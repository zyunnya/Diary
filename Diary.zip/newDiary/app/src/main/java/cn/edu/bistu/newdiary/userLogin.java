package cn.edu.bistu.newdiary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class userLogin extends AppCompatActivity {

    SharedPreferences shared;//创建SharedPreferences对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        Button login = (Button) findViewById(R.id.login);//登录按钮
        Button AddDefault = (Button) findViewById(R.id.AddDefault);//设置默认用户
        EditText username = (EditText) findViewById(R.id.username);//用户名文本
        shared  = getSharedPreferences("name",MODE_PRIVATE);//创建SharedPreferences对象
        SharedPreferences.Editor editor = shared.edit();//获取Editor对象

        login .setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(TextUtils.isEmpty(username.getText())){//文本框为空则启用shared默认的用户名

                    Intent i = getIntent();//得到修改默认用户界面传来的数据
                    String name = i.getStringExtra("username");//得到传来的用户名
                    username.setText(shared.getString("user",name));//设置到文本框
                    Toast toast = Toast.makeText(getApplicationContext(),//提示用户
                            "因为未输入用户名，启用默认的用户名", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }else{//如果不为空
                    String author = username.getText().toString();//得到作者名
                    Intent i = new Intent(userLogin.this , DiaryList.class);//intent跳转
                    //把数据传过去
                    i.putExtra("author",author);
                    startActivity(i);//执行跳转
                }

            }
        });

        AddDefault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(userLogin.this,addDefault.class);
                startActivity(intent);
            }
        });



    }

}