package cn.edu.bistu.newdiary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Date;

public class Diary extends AppCompatActivity {
    private DatabaseHelper dbHelper;//DatabaseHelper对象用来进行数据库操作

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary);

        Intent intent = getIntent();//得到list所点击的日记传来的数据
        int id = intent.getIntExtra("id",-1);//得到传来的id

        dbHelper = new DatabaseHelper(this,"DiaryDb.db",null,1);//数据库
        Button ChangeButton = (Button) findViewById(R.id.ChangeButton);//修改按钮
        Button ReturnButton = (Button) findViewById(R.id.ReturnButton);//添加图片按钮
        Button DeleteButton = (Button) findViewById(R.id.DeleteButton);//删除按钮

        EditText TitleText  = (EditText) findViewById(R.id.TitleText);//标题文本框
        TextView AuthorText = (TextView) findViewById(R.id.AuthorText);//作者文本框
        TextView TimeText = (TextView) findViewById(R.id.TimeText);//时间文本框
        EditText ContentText = (EditText) findViewById(R.id.ContentText);//内容文本框

        //用id从数据库钟得到所选中的那一块日记的所有数据
        SQLiteDatabase db = dbHelper.getWritableDatabase();//得到能够操作数据库的db

        //cursor得到对应的数据库的值
        Cursor cursor = db.query("diary",null,"d_id like ?",new String[]{String.valueOf(id)},null,null,null);
        cursor.moveToFirst();//回到第一行

        //开始赋予数据
        String  title = cursor.getString(cursor.getColumnIndex("d_title"));
        String  author = cursor.getString(cursor.getColumnIndex("d_author"));
        String  time = cursor.getString(cursor.getColumnIndex("d_time"));
        String  content = cursor.getString(cursor.getColumnIndex("d_content"));

        //对文本框进行编辑
        TitleText.setText(title);
        AuthorText.setText("作者：" + author);
        TimeText.setText("时间：" + time);
        ContentText.setText(content);

        ChangeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();//开始编写update信息
                Date time = new Date(System.currentTimeMillis());//得到当前时间

                //插入信息
                values.put("d_title",TitleText.getText().toString());
                values.put("d_time", String.valueOf(time));
                values.put("d_content",ContentText.getText().toString());
                db.update("diary",values,"d_id = ?",new String[]{String.valueOf(id)});//执行update

            }
        });

        ReturnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //复刻userLogin的登录按钮

                Intent intent2 = new Intent(Diary.this,DiaryList.class);
                intent2.putExtra("author",author);
                startActivity(intent2);
            }
        });

        DeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db.delete("diary","d_id = ?",new String[]{String.valueOf(id)});//把指定的id的那一数据删除

                //复刻userLogin

                Intent intent2 = new Intent(Diary.this,DiaryList.class);
                intent2.putExtra("author",author);
                startActivity(intent2);
            }
        });


    }


}