package cn.edu.bistu.newdiary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class addDefault extends AppCompatActivity {

    SharedPreferences shared;//创建SharedPreferences对象

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_default);

        Button add_button = (Button) findViewById(R.id.add_button);//添加按钮
        EditText username = (EditText) findViewById(R.id.username);//添加用户名的编辑框
        shared = getSharedPreferences("name",MODE_PRIVATE);//SharedPreferences用来存放默认用户
        SharedPreferences.Editor editor = shared.edit();//获取Editor对象
        username.setText(shared.getString("username","username"));

        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = username.getText().toString();//得到文本框的字符串
                editor.putString("username",name);//存入Editor对象
                if(TextUtils.isEmpty(username.getText()) || username.getText().toString().equals("")){//如果是空的
                    editor.putString("username","无名");//存默认用户名无名
                }
                editor.commit();//提交

                Intent intent = new Intent(addDefault.this,userLogin.class);//跳转回登陆界面
                intent.putExtra("username",shared.getString("username","无名"));//传递名字过去
                startActivity(intent);//跳转
            }
        });
    }
}