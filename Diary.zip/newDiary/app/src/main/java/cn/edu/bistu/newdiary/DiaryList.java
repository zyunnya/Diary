package cn.edu.bistu.newdiary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class DiaryList extends AppCompatActivity {
    private DatabaseHelper dbHelper;//DatabaseHelper对象用来进行数据库操作

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        dbHelper = new DatabaseHelper(this,"DiaryDb.db",null,1);//数据库

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_list);

        Intent intent = getIntent();
        String author = intent.getStringExtra("author");
        SQLiteDatabase db = dbHelper.getWritableDatabase();//得到能够操作数据库的db

        ArrayList<String> titleExtra = new ArrayList<String>();//得到从登陆界面传来的标题列表
        ArrayList<Integer> idExtra = new ArrayList<Integer>();//用来查找对应的日记

        Cursor cursor = db.query("diary",null,"d_author like ?",new String[]{author},null,null,null);
        if(cursor.moveToFirst()){//开始循环得到数据
            do{
                //遍历Cursor对象，取出数据并打印
                String  title = cursor.getString(cursor.getColumnIndex("d_title"));//得到标题
                int id = cursor.getInt(cursor.getColumnIndex("d_id"));//得到id
                titleExtra.add(title);//标题存到列表里
                idExtra.add(id);//id存到列表里
            }while(cursor.moveToNext());
        }
        cursor.close();//关闭cursor

        String[] title = new String[titleExtra.size()];//给ArrayAdapter适配器传送data
        for(int i = 0;i < titleExtra.size();i++){
            title[i] = titleExtra.get(i);//将标题列表里的值赋予给data
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,title);//适配器
        ListView listView = (ListView) findViewById(R.id.list_view);//得到ListView
        listView.setAdapter(adapter);//设置适配器

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {//ListView的点击事件
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int id = idExtra.get(i);//得到所选中的那一栏的id
                Intent intent = new Intent(DiaryList.this , Diary.class);//跳转
                intent.putExtra("id",id);//把id传过去
                startActivity(intent);//开始跳转
            }
        });

        Button AddDiary = (Button) findViewById(R.id.AddDiary);//添加日记的按钮
        AddDiary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = getIntent();//得到来自Login的跳转
                String author = intent.getStringExtra("author");//得到传来的author
                Intent intent2 = new Intent(DiaryList.this, writeDiary.class);//跳转到编写日记界面
                intent2.putExtra("author",author);//把作者名传过去
                startActivity(intent2);//开始跳转
            }
        });

        Button ReturnLogin = (Button) findViewById(R.id.ReturnLogin);//退出按钮
        ReturnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DiaryList.this,userLogin.class);//返回到登陆界面
                startActivity(intent);//开始跳转
            }
        });

    }
}