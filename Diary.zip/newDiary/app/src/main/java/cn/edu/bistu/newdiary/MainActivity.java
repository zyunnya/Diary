package cn.edu.bistu.newdiary;


import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this,"DiaryDb.db",null,1);
        Button createDatabase = (Button) findViewById(R.id.create_databse);
        createDatabase.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                dbHelper.getWritableDatabase();
            }
        });

        //添加数据
        Button addData = (Button) findViewById(R.id.add_data);
        addData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                //開始組裝第一條數據
                values.put("d_author", "东海帝王");
                values.put("d_title", "有马纪念夺冠");
                values.put("d_content", "東海帝王か、東海帝王が来た！！東海帝王が来た！！琵琶ハヤ光と東海帝王！！ダービー馬の意地を見せるか！？東海帝王だ！東海帝王だ！東海帝王！！奇跡の復活！");
                Date time = new Date(System.currentTimeMillis());
                values.put("d_time", String.valueOf(time));
                db.insert("diary", null, values);//插入第一條數據

            }
        });

        //修改数据
        Button updateData = (Button) findViewById(R.id.update_data);
        updateData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                ContentValues values = new ContentValues();
                values.put("d_title","莉莉丝新皮配音");
                db.update("diary",values,"d_id = ?",new String[]{"1"});
            }
        });

        //删除数据
        Button deleteButton = (Button) findViewById(R.id.delete_data);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                db.delete("diary","d_id = ?",new String[]{"1"});
            }
        });

        //查找数据
        Button queryButton = (Button) findViewById(R.id.query_data);
        queryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SQLiteDatabase db = dbHelper.getWritableDatabase();
                //查询Book表钟的所有数据
                Cursor cursor = db.query("diary",null,null,null,null,null,null);
                if(cursor.moveToFirst()){
                    do{
                        //遍历Cursor对象，取出数据并打印
                        String author = cursor.getString(cursor.getColumnIndex("d_author"));
                        String  title = cursor.getString(cursor.getColumnIndex("d_title"));
                        String con = cursor.getString(cursor.getColumnIndex("d_content"));
                        String time = cursor.getString(cursor.getColumnIndex("d_time"));
                        Log.d("MainActivity","diary author is " + author);
                        Log.d("MainActivity","diary title is " + title);
                        Log.d("MainActivity","diary content is " + con);
                        Log.d("MainActivity","diar time is " + time);
                    }while(cursor.moveToNext());
                }
                cursor.close();
            }
        });

    }
}