package cn.edu.bistu.newdiary;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Date;

public class writeDiary extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_diary);

        Intent intent = getIntent();//得到来自DiaryList传来的数据
        String author = intent.getStringExtra("author");//得到作者名

        DatabaseHelper dbHelper = new DatabaseHelper(this,"DiaryDb.db",null,1);//数据库

        Button AddButton = (Button) findViewById(R.id.AddButton);//添加按钮
        Button CancelButton = (Button) findViewById(R.id.CancelButton);//取消按钮

        EditText TitleText  = (EditText) findViewById(R.id.TitleText);//标题文本框
        TextView AuthorText = (TextView) findViewById(R.id.AuthorText);//作者文本框
        AuthorText.setText("作者：" + author);//设置作者名
        TextView TimeText = (TextView) findViewById(R.id.TimeText);//时间文本框
        Date time = new Date(System.currentTimeMillis());//当前时间
        TimeText.setText("时间：" + String.valueOf(time));//设置事件
        EditText ContentText = (EditText) findViewById(R.id.ContentText);//内容文本框

        SQLiteDatabase db = dbHelper.getWritableDatabase();//读取数据库信息

        AddButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ContentValues values = new ContentValues();//开始编写insert信息

                String title = TitleText.getText().toString();//得到标题的信息
                String content = ContentText.getText().toString();//得到内容的信息
                //编写values
                values.put("d_title",title);
                values.put("d_time", String.valueOf(time));
                values.put("d_author",author);
                values.put("d_content",content);
                db.insert("diary",null,values);//执行insert

                //以下复刻userLogin的登录按钮，返回list

                Intent intent2 = new Intent(writeDiary.this,DiaryList.class);
                intent2.putExtra("author",author);
                startActivity(intent2);
            }
        });

        CancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //复刻userLogin的登录按钮，返回list
                Intent intent2 = new Intent(writeDiary.this,DiaryList.class);
                intent2.putExtra("author",author);
                startActivity(intent2);
            }
        });



    }
}